# Välkommen, läkare!

Detta gränssnitt ger tillgång till:
- Symptom- och funktionsdata
- Tolkade AI-förslag
- Glukos-, hjärtfrekvens- och labbpaneler
- Möjlighet att filtrera datakällor

För att börja, välj en vy från menyn.