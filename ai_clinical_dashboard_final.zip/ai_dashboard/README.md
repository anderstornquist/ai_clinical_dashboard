# AI Clinical Dashboard

En plattform för klinisk analys och AI-baserad tolkning av hälsodata. Se `README_DOCTOR.md` för klinisk användning.