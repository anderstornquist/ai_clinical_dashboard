
import streamlit_authenticator as stauth
import yaml
import streamlit as st

def login():
    with open("config/credentials.yaml") as file:
        config = yaml.safe_load(file)
    authenticator = stauth.Authenticate(
        config['credentials'], config['cookie']['name'],
        config['cookie']['key'], config['cookie']['expiry_days']
    )
    name, auth_status, username = authenticator.login("Login", "main")
    if auth_status:
        return name, username
    elif auth_status is False:
        st.error("Fel användarnamn/lösenord")
        st.stop()
    else:
        st.warning("Vänligen logga in")
        st.stop()
