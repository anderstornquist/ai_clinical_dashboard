
import streamlit as st
import yaml
import bcrypt
from pathlib import Path

CREDENTIALS_PATH = Path("config/credentials.yaml")

def load_credentials():
    with open(CREDENTIALS_PATH, "r") as f:
        return yaml.safe_load(f)

def save_credentials(data):
    with open(CREDENTIALS_PATH, "w") as f:
        yaml.dump(data, f, sort_keys=False)

def hash_password(password):
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def admin_ui():
    st.title("Adminpanel – Användarhantering")

    credentials = load_credentials()
    usernames = list(credentials["credentials"]["usernames"].keys())

    st.subheader("📋 Befintliga användare")
    for user in usernames:
        user_data = credentials["credentials"]["usernames"][user]
        st.markdown(f"**{user}** – {user_data['name']} ({user_data['email']})")

    st.subheader("➕ Lägg till ny användare")
    new_username = st.text_input("Användarnamn")
    new_name = st.text_input("Namn")
    new_email = st.text_input("E-post")
    new_password = st.text_input("Lösenord", type="password")

    if st.button("Skapa användare"):
        if new_username in usernames:
            st.warning("Användarnamn finns redan.")
        else:
            credentials["credentials"]["usernames"][new_username] = {
                "name": new_name,
                "email": new_email,
                "password": hash_password(new_password)
            }
            save_credentials(credentials)
            st.success(f"Användare {new_username} skapad.")

    st.subheader("🔁 Återställ lösenord")
    target_user = st.selectbox("Välj användare", usernames)
    new_pw = st.text_input("Nytt lösenord", type="password", key="reset_pw")

    if st.button("Uppdatera lösenord"):
        credentials["credentials"]["usernames"][target_user]["password"] = hash_password(new_pw)
        save_credentials(credentials)
        st.success(f"Lösenord uppdaterat för {target_user}.")
