
import streamlit as st
st.header("Symptom-board")
st.write("Här visas aggregerade symptomdata över tid, med möjlighet att filtrera efter domän, bias och tid.")
