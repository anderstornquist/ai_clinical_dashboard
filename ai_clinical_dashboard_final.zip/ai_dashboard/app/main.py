
import streamlit as st
st.set_page_config(page_title="AI Clinical Dashboard", layout="wide")
st.title("AI-baserat analysverktyg för klinisk data")
st.write("Välj en analyspanel från menyn till vänster.")
